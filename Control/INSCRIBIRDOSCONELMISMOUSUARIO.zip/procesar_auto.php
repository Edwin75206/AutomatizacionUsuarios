<?php
require 'config.php';
require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$db = getDb();
$mailCfg = require 'mail_config.php';
$cookieFile = __DIR__ . '/edx_cookies.txt';

$baseUrl = 'http://local.openedx.io';
$rootUrl = $baseUrl . '/';
$loginApi = $baseUrl . '/api/user/v1/account/login_session/';
$registerApi = $baseUrl . '/api/user/v1/account/registration/';
$enrollApi = $baseUrl . '/api/enrollment/v1/enrollment';

function getCsrf(string $cookieFile): string
{
    if (!file_exists($cookieFile)) return '';
    foreach (file($cookieFile, FILE_IGNORE_NEW_LINES) as $line) {
        if (preg_match('/\tcsrftoken\t([^\t]+)$/', $line, $m)) return $m[1];
    }
    return '';
}

$id = $_GET['id'] ?? null;
if (!$id) exit('ID de usuario no especificado');

$stmt = $db->prepare('SELECT * FROM usuarios WHERE id = ?');
$stmt->execute([$id]);
$usr = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$usr) exit('Usuario no encontrado');

$username = $usr['username'];

// Verificar si hay duplicado con mismo correo pero distinto nombre o curso
$stmtCheck = $db->prepare('SELECT * FROM usuarios WHERE correo = ? ORDER BY id ASC');
$stmtCheck->execute([$usr['correo']]);
$usuariosMismoCorreo = $stmtCheck->fetchAll(PDO::FETCH_ASSOC);

$esDuplicado = false;
$cont = 1;
$correoOriginal = $usr['correo'];

foreach ($usuariosMismoCorreo as $reg) {
    if (
        $reg['id'] != $id &&
        ($reg['nombre'] != $usr['nombre'] || $reg['curso'] != $usr['curso'])
    ) {
        $esDuplicado = true;
        break;
    }
}

if ($esDuplicado) {
    $correoParts = explode('@', $usr['correo']);
    do {
        $nuevoCorreo = $correoParts[0] . "+$cont@" . $correoParts[1];
        $stmtTmp = $db->prepare('SELECT COUNT(*) FROM usuarios WHERE correo = ?');
        $stmtTmp->execute([$nuevoCorreo]);
        $cont++;
    } while ($stmtTmp->fetchColumn() > 0);
    $db->prepare('UPDATE usuarios SET correo = ? WHERE id = ?')->execute([$nuevoCorreo, $id]);
    $usr['correo'] = $nuevoCorreo;
}

// 1. GET inicial para CSRF
unlink($cookieFile);
for ($i = 0; $i < 2; $i++) {
    $ch = curl_init($rootUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_COOKIEJAR => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_HTTPHEADER => [
            'Referer: ' . $rootUrl,
            'User-Agent: Mozilla/5.0'
        ]
    ]);
    curl_exec($ch);
    curl_close($ch);
}
$csrf = getCsrf($cookieFile);
if (!$csrf) die('No se encontró CSRF inicial.');

// 2. Registro en Open edX
$data = [
    'username' => $usr['username'],
    'password' => $usr['password_plain'],
    'email' => $usr['correo'],
    'name' => $usr['nombre'] . ' ' . $usr['apellido'],
    'country' => 'MX',
    'honor_code' => true,
    'terms_of_service' => true,
];
$ch = curl_init($registerApi);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_COOKIEJAR => $cookieFile,
    CURLOPT_COOKIEFILE => $cookieFile,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => http_build_query($data),
    CURLOPT_HTTPHEADER => [
        "X-CSRFToken: $csrf",
        "Referer: $rootUrl",
        'Content-Type: application/x-www-form-urlencoded',
    ],
]);
$res = curl_exec($ch);
$st = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$successAlta = ($st >= 200 && $st < 300);
if (!$successAlta) {
    $db->prepare('UPDATE usuarios SET alta=0, error_message=? WHERE id=?')->execute(["HTTP $st: $res", $id]);
    exit("Error al registrar: HTTP $st");
}
$db->prepare('UPDATE usuarios SET alta=1 WHERE id=?')->execute([$id]);

// 3. Login admin
unlink($cookieFile);
$ch = curl_init($rootUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_COOKIEJAR => $cookieFile,
    CURLOPT_COOKIEFILE => $cookieFile,
]);
curl_exec($ch);
curl_close($ch);
$csrf = getCsrf($cookieFile);
if (!$csrf) die('No se encontró CSRF tras limpiar cookies.');

$loginQry = http_build_query([
    'email' => 'admin@academus.mx',
    'password' => 'Academus2025#',
]);
$ch = curl_init($loginApi);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_COOKIEJAR => $cookieFile,
    CURLOPT_COOKIEFILE => $cookieFile,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $loginQry,
    CURLOPT_HTTPHEADER => [
        "X-CSRFToken: $csrf",
        "Referer: $rootUrl",
        'Content-Type: application/x-www-form-urlencoded',
    ],
]);
$resp = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
if ($code !== 200) die("Login falló: HTTP $code → $resp");

// Refrescar CSRF
$ch = curl_init($rootUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_COOKIEJAR => $cookieFile,
    CURLOPT_COOKIEFILE => $cookieFile,
]);
curl_exec($ch);
curl_close($ch);
$csrf = getCsrf($cookieFile);

// 4. Enroll usuario
$mapCursos = [
    '1° Primaria' => 'course-v1:Preescolar+CAD001+2025_MAR',
    '2° Primaria' => 'course-v1:Unimec+CAD001+2025_MAR',
];
$nombreCurso = $usr['curso'] ?? '';
$course_id = $mapCursos[$nombreCurso] ?? null;

if (!$course_id) {
    $db->prepare('UPDATE usuarios SET asignado=0, notificado=0, error_message=? WHERE id=?')
        ->execute(["Curso no reconocido: $nombreCurso", $id]);
    exit;
}

$enrollData = [
    'user' => $usr['username'],
    'course_details' => [
        'course_id' => $course_id,
        'mode' => 'honor',
    ],
];
$payload = json_encode($enrollData);

$ch = curl_init($enrollApi);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_COOKIEJAR => $cookieFile,
    CURLOPT_COOKIEFILE => $cookieFile,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $payload,
    CURLOPT_HTTPHEADER => [
        "X-CSRFToken: $csrf",
        "Referer: $enrollApi",
        'Content-Type: application/json',
    ],
]);
$res = curl_exec($ch);
$st = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($st >= 200 && $st < 300) {
    $db->prepare('UPDATE usuarios SET asignado=1 WHERE id=?')->execute([$id]);
} else {
    $db->prepare('UPDATE usuarios SET asignado=0, notificado=0, error_message=? WHERE id=?')
        ->execute(["HTTP $st: $res", $id]);
    exit("Error al inscribir: HTTP $st");
}

// 5. Enviar correo
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = $mailCfg['smtp']['host'];
    $mail->SMTPAuth = true;
    $mail->Username = $mailCfg['smtp']['username'];
    $mail->Password = $mailCfg['smtp']['password'];
    $mail->SMTPSecure = $mailCfg['smtp']['encryption'];
    $mail->Port = $mailCfg['smtp']['port'];

    $mail->setFrom($mailCfg['smtp']['from_email'], $mailCfg['smtp']['from_name']);
    $mail->addAddress($usr['correo'], $usr['nombre'] . ' ' . $usr['apellido']);
    $mail->isHTML(true);
    $mail->Subject = 'Bienvenido a la Plataforma de Aprendizaje – Cuenta de acceso';
    $mail->Body = "<p>👋 Estimado(a) <strong>{$usr['nombre']} {$usr['apellido']}</strong>,</p>
        <p>🎓 ¡Bienvenido(a) a nuestra plataforma <strong>Academus Digital</strong>!</p>
        <p><strong>🔐 Datos de acceso:</strong></p>
        <ul>
            <li>👤 <strong>Usuario:</strong> {$usr['username']}</li>
            <li>📧 <strong>Correo:</strong> {$usr['correo']}</li>
            <li>🔑 <strong>Contraseña temporal:</strong> {$usr['password_plain']}</li>
            <li>🌐 <strong>Enlace:</strong> <a href='https://app.academusdigital.com'>https://app.academusdigital.com</a></li>
        </ul>
        <p>💡 Puedes iniciar sesión con tu usuario o correo electrónico. No olvides cambiar tu contraseña.</p>
        <p>💙 <strong>Equipo de Academus Digital</strong></p>";

    $mail->send();
    $db->prepare('UPDATE usuarios SET notificado=1 WHERE id=?')->execute([$id]);
} catch (Exception $e) {
    $db->prepare('UPDATE usuarios SET notificado=0, error_message=? WHERE id=?')->execute([$mail->ErrorInfo, $id]);
}

header('Location: registro_exitoso.php');
exit;
?>
